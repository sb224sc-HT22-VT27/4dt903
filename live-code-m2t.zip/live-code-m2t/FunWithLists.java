package olympicsm2tlive.utils;

import java.util.List;

public class FunWithLists {

	public static <T> List<T> reverseListInJava(List<T> list){
		return list.reversed();
	}
	
}
